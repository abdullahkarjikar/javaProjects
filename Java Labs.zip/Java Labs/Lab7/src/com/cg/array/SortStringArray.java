package com.cg.array;

import java.util.Arrays;
import java.util.Scanner;

public class SortStringArray {
	public static void main(String[] args) {
		String[] string = null;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the string size");
		int size = scanner.nextInt();
		string = new String[size];
		scanner.nextLine();
		for (int i = 0; i < string.length; i++) {
			System.out.println("Enter string " + (i + 1));
			string[i] = scanner.nextLine();
		}
		Arrays.sort(string);
		System.out.println("Sorted String Array is: ");
		for (String string2 : string) {
			System.out.println(string2);
		}
		scanner.close();

	}

}

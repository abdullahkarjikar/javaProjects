package com.cg.array;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ArrayListSorting {
	public static void main(String[] args) {
		List<String> products = new ArrayList<>();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter size: ");
		int size = scanner.nextInt();
		scanner.nextLine();
		for (int i = 0; i < size; i++) {
			System.out.println("Enter string " + (i + 1));
			String string = scanner.nextLine();
			products.add(string);
		}
		Collections.sort(products);
		System.out.println("Sorted String is: ");
		for (String string : products) {
			System.out.println(string);
		}
		scanner.close();
	}

}

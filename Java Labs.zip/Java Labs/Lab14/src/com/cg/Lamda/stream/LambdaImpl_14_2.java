//11.2: Write a method that uses lambda expression to format a given string, where a space is inserted between each character of string. For ex., if input is �CG�, then expected output is �C G�.
package com.cg.Lamda.stream;

public interface LambdaImpl_14_2 {

	public static void main(String[] args) {

		LambdaInterface_14_2 lm = (str) -> {
			String temp = "";
			for (int i = 0; i < str.length(); i++) {
				temp = temp + str.charAt(i) + " ";

			}
			return temp;
		};
		System.out.println(lm.modifyString("kathir"));
	}
}

//11.2
package com.cg.Lamda.stream;

public interface LambdaInterface_14_2 
{
	public abstract String modifyString(String str);
}

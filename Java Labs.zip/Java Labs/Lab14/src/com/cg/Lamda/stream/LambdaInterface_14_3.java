//11.3
package com.cg.Lamda.stream;

public interface LambdaInterface_14_3 
{
	public abstract boolean validation(String userName, String password);
}

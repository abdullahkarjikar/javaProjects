package com.cg.client;

import com.cg.person.Person;

public class Lab2_4 {
	public static void main(String[] args) {
		Person person= new Person("Raj","khan","M",20,85.55d);
		person.displayDetails();
	}

}

package com.cg.client;

import com.cg.person.Person;

public class PersonMain {
	
	public static void main(String[] args) {
		Person person= new Person("Rishi","khanna","M",20,85.55d);
		
		System.out.println("First Name: "+person.getFirstName());
		System.out.println("Last Name: "+person.getLastName());
		System.out.println("Gender: "+person.getGender());
		System.out.println("Age: "+person.getAge());
		System.out.println("Weight: "+person.getWeight());
	}

}

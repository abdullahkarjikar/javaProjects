package com.cg.client;

import java.util.Scanner;

public class PositiveNegative {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Number: ");
		if(scanner.nextInt()>0) {
			System.out.println("Positive");
		}else {
			System.out.println("Negative");
		}
		scanner.close();
	}

}

package com.cg.client;

import com.cg.person.Person;

public class Main {
	public static void main(String[] args) {
		Person person = new Person();
		person.setFirstName("Rishi");
		person.setLastName("khanna");
		person.setGender("M");
		person.setAge(20);
		person.setWeight(85.55d);
		
		System.out.println("First Name: "+person.getFirstName());
		System.out.println("Last Name: "+person.getLastName());
		System.out.println("Gender: "+person.getGender());
		System.out.println("Age: "+person.getAge());
		System.out.println("Weight: "+person.getWeight());
	}

}

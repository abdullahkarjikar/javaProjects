package com.cg.client;

import java.util.Scanner;

import com.cg.person.Person;
import com.cg.person.Person.Gender;

public class Lab2_5 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		Person person = new Person();
		System.out.println("Enter first Name: ");
		person.setFirstName(scanner.nextLine());
		System.out.println("Enter last Name: ");

		person.setLastName(scanner.nextLine());
		System.out.println("Enter age: ");

		person.setAge(scanner.nextInt());
		System.out.println("Enter weight: ");

		person.setWeight(scanner.nextDouble());
		System.out.println("Enter Gender (M or F: " );
		scanner.nextLine();
		String gender=scanner.nextLine();
		if(gender.equals(Gender.F)) {
			person.setGender("F");
		}
		
		if(gender.equals(Gender.M)) {
			person.setGender("M");
		}
		
		
		System.out.println("First Name: "+person.getFirstName());
		System.out.println("Last Name: "+person.getLastName());
		System.out.println("Gender: "+person.getGender());
		System.out.println("Age: "+person.getAge());
		System.out.println("Weight: "+person.getWeight());
		scanner.close();
	}
}

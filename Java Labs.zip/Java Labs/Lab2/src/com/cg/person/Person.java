package com.cg.person;

public class Person {

	String firstName;
	String lastName;
	String gender;
	int age;
	double weight;
	long phoneNo;
	
	
	public void displayDetails() {
		System.out.println("First Name: "+getFirstName());
		System.out.println("Last Name: "+getLastName());
		System.out.println("Gender: "+getGender());
		System.out.println("Age: "+getAge());
		System.out.println("Weight: "+getWeight());
		System.out.println("Phone No: "+getPhoneNo());
	}
	public enum Gender {
	    M, F
	}
	
	
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public Person(String firstName, String lastName, String gender, int age, double weight) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
	}
	public Person() {
		// TODO Auto-generated constructor stub
	}
	public void setGender(Gender f) {
		
	}
	
}

package com.cg.filehandling;

public class Employee 
{
	int empId;
	String empName;
	double empSalary;
	String empDesignation;
	String empInsuranceScheme;
	
	
	public Employee(int empId, String empName, double empSalary,
			String empDesignation) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empDesignation = empDesignation;
		
	}
	
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	public String getEmpInsuranceScheme() {
		return empInsuranceScheme;
	}
	public void setEmpInsuranceScheme(String empInsuranceScheme) {
		this.empInsuranceScheme = empInsuranceScheme;
	}


	@Override
	public String toString() {
		return "Employee [Id=" + empId + ", Name=" + empName
				+ ", Salary=" + empSalary + ", Designation="
				+ empDesignation + ", InsuranceScheme=" + empInsuranceScheme
				+ "]";
	}
	
	
	 
}


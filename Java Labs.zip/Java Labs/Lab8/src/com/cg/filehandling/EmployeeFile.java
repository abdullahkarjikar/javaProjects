//9.3: Enhance the lab assignment 6.3 by adding functionality in service class to write employee objects into a File. Also read employee details from file and display the same in console. Analyze the output of the program.

package com.cg.filehandling;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;



public class EmployeeFile {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException, InterruptedException 
	{
		Employee emp[] = new Employee[8];
		emp[1] = new Employee(101, "kathir", 50000, "Manager");
		emp[2] = new Employee(102, "nihal", 35000, "Programmer");
		emp[3] = new Employee(103, "vinod", 12000, "System Associate");
		emp[4] = new Employee(104, "surya", 11000, "System Associate");
		emp[5] = new Employee(105, "saravana", 35000, "Programmer");
		emp[6] = new Employee(106, "kumar", 4000, "Clerk");
		emp[7] = new Employee(107, "varun", 10000, "System Associate");
		
		
		File file1 = new File("C:\\Users\\kathi\\eclipse-workspace\\LabAssign\\src\\com\\cg\\filehandling\\Employee.txt");
		File fout = new File("C:\\Users\\kathi\\eclipse-workspace\\LabAssign\\src\\com\\cg\\filehandling\\Employee.txt");
		FileOutputStream toFile ;
		toFile = new FileOutputStream("C:\\Users\\kathi\\eclipse-workspace\\LabAssign\\src\\com\\cg\\filehandling\\Employee.txt");
		String temp = "";
		System.out.println("Writing data into files........");
		for(int i =1;i<=7;i++)
		{
			temp = "";
			temp = temp + emp[i].getEmpId();
			for(int j=0;j<temp.length();j++)
			{
				
				int k = temp.charAt(j);
				toFile.write(k);
			}
			toFile.write(32);
			
			temp="";
			temp = temp + emp[i].getEmpName();
			for(int j=0;j<temp.length();j++)
			{
				
				int k = temp.charAt(j);
				toFile.write(k);
			}
			toFile.write(32);
			temp="";
			temp = temp + emp[i].getEmpDesignation();
			for(int j=0;j<temp.length();j++)
			{
				
				int k = temp.charAt(j);
				toFile.write(k);
			}
			toFile.write(32);
			
			toFile.write(10);
			
		}
		
		System.out.println("Retriving data from the file");
		Scanner sc = new Scanner(file1);
		for(int i=1; i <=7 ; i++)
		{
			System.out.println(sc.nextLine());
			Thread.sleep(1000);
		}

	}

}

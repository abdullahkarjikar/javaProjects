package com.cg.filehandling;

	import java.io.FileInputStream;
	import java.io.FileOutputStream;
	import java.io.IOException;

	public class ContentReverse 
	{

		@SuppressWarnings("resource")
		public static void main(String[] args) throws IOException 
		{
			FileInputStream fromFile;
			FileOutputStream toFile ;
			String fileName = "C:\\Users\\kathi\\eclipse-workspace\\LabAssign\\src\\com\\cg\\filehandling\\source.txt";
			String fileName1 = "C:\\Users\\kathi\\eclipse-workspace\\LabAssign\\src\\com\\cg\\filehandling\\target.txt";
			fromFile = new FileInputStream(fileName);
			toFile = new FileOutputStream(fileName1);
			int i = fromFile.read();
			
			String st ="" + (char)i;
			
			while (i != -1) { //check the end of file
				//toFile.write(i);
				
				i = fromFile.read();
				st = st + (char)i;
			}
			
			for(int j=st.length()-2;j>=0;j--)
			{
				
				int k = st.charAt(j);
				toFile.write(k);
			}
			System.out.println(st);
		}
	}



package com.cg.testing.exception.test;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.testing.exception.ExceptionCheck;
import com.cg.testing.service.EmployeeService;
import com.cg.testing.service.EmployeeServiceImp;

public class EmployeeServiceImpTest {
	EmployeeServiceImpTest object;

	@Before
	public void setUp() throws Exception {
		object = new EmployeeServiceImpTest();
	}

	@After
	public void tearDown() throws Exception {
		object = null;
	}

	@Test(expected = ExceptionCheck.class)
	public void testValidSal() throws ExceptionCheck {

		EmployeeService service = new EmployeeServiceImp();
			service.validSal(2000d);

	}

}

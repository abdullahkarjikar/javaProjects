package com.cg.testing.exception;

@SuppressWarnings("serial")
public class ExceptionCheck extends Exception {

	public ExceptionCheck(String message) {
		super(message);
	}

}
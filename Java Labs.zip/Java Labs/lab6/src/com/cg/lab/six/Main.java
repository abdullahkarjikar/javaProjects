package com.cg.lab.six;

import java.util.InputMismatchException;
import java.util.Scanner;



public class Main {

	public void checkAge() throws AgeExceptions {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your name");
		String name = scanner.nextLine();
		System.out.println("Enter Age:");
		int age = 0;

		try {
			age = scanner.nextInt();
		} catch (InputMismatchException exception) {
			throw new AgeExceptions("Age should contain only digits");
		}
		if (age >= 15) {
			System.out.println("Thank you.");
		} else {
			System.err.println("Age should be above 15");

		}
	}
	
	public static void main(String[] args) {

		Main main = new Main();
		try {
			main.checkAge();
		} catch (AgeExceptions e) {
			System.out.println(e.getMessage());
		}

	}
	
}

package com.cg.eis.service;

public interface EmployeeService {

	String validateFields(double salary,String designation);

}
